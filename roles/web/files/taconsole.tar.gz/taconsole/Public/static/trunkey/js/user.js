
//搜索框
//触发 		
	function cls(){  
		with(event.srcElement)  
	
		if(value==defaultValue) value="";

		//propertychange  ie专用
		$('#sousuo').on('propertychange',function () {
			if($('#sousuo').val() != '用户名或真实姓名' && $('#sousuo').val().length > 0 ) {
//				$('#ss_icon').css('background-image','url(img/ss_gb.png)');
//				$('#ss_icon_close').css('display','block');
//				$('#ss_icon').css('display','none');
				$('#ss_icon').css('display','block');
				
			}else {
//				$('#ss_icon').css('background-image','url(img/sousuo.png)');
				$('#ss_icon').css('display','block');
				$('#ss_icon_close').css('display','none');	
			}
		});
	}
	
	//失去
	function res(){ 
		
		$('#ss_icon_close').on('click',function(){
			$('#sousuo').val('用户名或真实姓名');	
		})
		
		with(event.srcElement)  	
		if(value=="") value=defaultValue;
			
	} 

 
 
 $(document).on('keydown',function(event) {
//	alert(0);
	if(event.keyCode == 13) {
		if($('.user').val() == "" || $('.password').val() == "" ) {
			$(".tishi").html('账号密码不能为空！');
		}
		else if($('.user').val() != "" && $('.password').val() != "" ) {		
			$(".tishi").html('用户名或密码错误，请重新输入！');
		}
	}
});

//弹窗筛查
//创建新用户

$("#xj").click(
	function(){
		$("#tooltip_box_c").find(".yhm,.mima,.qrmima").attr("value","")
		$(".yhm_div").hide()
		$(".mima_div").hide()
		$(".qrmima_div").hide()
	}
)
$("#tooltip_box_c #qd").click(
	function(){
		if($(".yhm").val()==''){
			$(".yhm_div").html('用户名不能为空').addClass("ts_h").show()
			return false
		}else{
			$(".yhm_div").hide()
		}
		if($(".mima").val().length<6){
			$(".mima_div").html('密码至少为六位数').addClass("ts_h").show()
			return false
		}
		else{
			$(".mima_div").hide()
		}
		if($(".qrmima").val()!=$(".mima").val()){
			$(".qrmima_div").html('两次密码输入不一致').addClass("ts_h").show()
			return false
		}else{
			$(".yhm_div").hide()
			$(".mima_div").hide()
			$(".qrmima_div").hide()

			$("#tooltip_box_c").hide()
            create_user();
		}
	}

)

function create_user(){
    var createcount = $(".createcount").val();
    var username = $(".yhm").val();
    var truename = $(".truename").val();
    var password = $(".mima").val();
    var limitcount = $(".limitcount").val();

    var data = {"username":username,"truename":truename,"password":password,"createcount":createcount,"limitcount" : limitcount};
    $.post("index.php?s=/home/User/user_add",data, function(result) {
        var func = "location.href='index.php?s=/home/index/index'";
        message(result,func);
    },"json");

}

$("#ym_qd").click(function(){
    var page = parseInt($(".ym_ys").val());
    if(page >= (PAGE_NUM )) {
        page = PAGE_NUM -1 ;
    }else if(page <= 0){
        page = 0 ;
    }else{
        page = page -1 ;
    }
    location.href="index.php?s=/home/index/index&p="+page;
});

function mark(uid){
   delete_username = [];
   delete_username.push(uid);
}

function update_user(){
    var len = delete_username.length ;
    var failure = 0 ;
    var ret = {};

    if(1 == len){
        var truename = $(".usertruename").val();
        var userpasswd = $(".userpasswd").val();
        var userlimit  = $(".userlimit").val();
        var data ={"uid":delete_username[0],"truename" : truename,"passwd":userpasswd,'limit':userlimit};
        $.post("index.php?s=/home/User/user_modify",data, function(result) {
            var func = "location.href='index.php?s=/home/index/index'";
            message(result,func);
        }, 'json');
        delete_username = [];
    }else{
        for( i in delete_username){
            var batch_passwd = $(".batchpasswd").val();
            var batch_limit  = $(".batchlimit").val();
            var data ={"uid":delete_username[i],"passwd":batch_passwd,"limit":batch_limit};
            $.post("index.php?s=/home/User/user_modify",data, function(result) {
            }, 'json');
        }
        delete_username = [];
        ret['status'] = 1 ;
        ret['info']   = len+"个用户修改成功，"+failure+"个用户修改失败。";
        var func = "location.href='index.php?s=/home/index/index'";
        message(ret,func);
    }
}

function destroy_user(){
    var len = delete_username.length ;
    var failure = 0 ;
    var ret = {};

    if(1 == len){
        var data ={"uid":delete_username[0]};
        $.post("index.php?s=/home/User/user_del",data, function(result) {
            var func = "location.href='index.php?s=/home/index/index'";
            message(result,func);
        }, 'json');
        delete_username = [];
    }else{
        for( i in delete_username){
            var data ={"uid":delete_username[i]};
            $.post("index.php?s=/home/User/user_del",data, function(result) {
            }, 'json');
        }
        delete_username = [];
        ret['status'] = 1 ;
        ret['info']   = len+"个用户删除成功，"+failure+"个用户删除失败。";
        var func = "location.href='index.php?s=/home/index/index'";
        message(ret,func);
    }
}

function reset_user(){
    var len = delete_username.length ;
    var failure = 0 ;
    var ret = {};

    if(1 == len){
        var data ={"uid":delete_username[0]};
        $.post("index.php?s=/home/User/user_reset",data, function(result) {
            var func = "location.href='index.php?s=/home/index/index'";
            message(result,func);
        }, 'json');
        delete_username = [];
    }else{
        for( i in delete_username){
            var data ={"uid":delete_username[i]};
            $.post("index.php?s=/home/User/user_reset",data, function(result) {
            }, 'json');
        }
        delete_username = [];
        ret['status'] = 1 ;
        ret['info']   = len+"个用户初始化成功，"+failure+"个用户初始化失败。";
        var func = "location.href='index.php?s=/home/index/index'";
        message(ret,func);
    }
}

//批量操作
function batch_op(operation){
    var users = [];
    $("input[ name = 'items' ]:checked").each(function () {
        users.push($(this).attr("uid"));
    });
    //判断是否选中了全选.
    if($("#CheckedAll").prop("checked")){
        users = userarr;
    }
    switch(operation){
        case "delete":
            delete_username = users;
            break;
        case "modify":
            delete_username = users;
            break;
        case "reset":
            delete_username = users;
            break;
        default:
            break;
    }
}

//用户搜索
function user_search(){
    var uname = $("#sousuo").val();
    if(uname == "用户名或真实姓名"){
        location.href='index.php?s=/home/index/index';
    }else{
        location.href='index.php?s=/home/index/index&search='+uname;
    }
}

 //用户搜索键盘事件
 
 $(document).on('keydown',function(e) {
//	alert(0);
	e = e || event;
	//搜索键盘13
	if(e.keyCode == 13 && $('#sousuo').val() != '用户名或真实姓名') {
		    var uname = $("#sousuo").val();
		    if(uname == "用户名或真实姓名"){
		        location.href='index.php?s=/home/index/index';
		    }else{
		        location.href='index.php?s=/home/index/index&search='+uname;
		    }

	}
//	防止tab键，页面整体向左移动
        if (e.keyCode == 9) {
            if (e.preventDefault) {e.preventDefault(); }
            else { e.returnValue = false; }
        }

	//创建用户键盘13
	else if(e.keyCode == 13 && ($(".yhm").val()!='') && ($(".qrmima").val()==$(".mima").val())) {
		if($(".yhm").val()==''){
			$(".yhm_div").html('用户名不能为空').addClass("ts_h").show()
			return false
		}else{
			$(".yhm_div").hide()
		}
		if($(".mima").val().length<6){
			$(".mima_div").html('密码至少为六位数').addClass("ts_h").show()
			return false
		}
		else{
			$(".mima_div").hide()
		}
		if($(".qrmima").val()!=$(".mima").val()){
			$(".qrmima_div").html('两次密码输入不一致').addClass("ts_h").show()
			return false
		}else{
			$(".yhm_div").hide()
			$(".mima_div").hide()
			$(".qrmima_div").hide()

			$("#tooltip_box_c").hide()
            create_user();
		}
	}
		
});

//刷新按钮
function refresh_a(){
//	alert(456)
    location.href='index.php?s=/home/index/index';
}

