
//输入框聚焦时样式改变
$(".username").focus(
			function(){
				$(this).parent().addClass("border_current")
				$(this).siblings().css("opacity","1")
				$(this).css("opacity","1")
			}
		)
 
 $(".username").blur(
			function(){
				$(this).parent().removeClass("border_current")
				$(this).siblings().css("opacity","0.6")
				$(this).css("opacity","0.6")
			}
		)
 $(".password").focus(
			function(){
				$(this).parent().addClass("border_current")
				$(this).siblings().css("opacity","1")
				$(this).css("opacity","1")
			}
		)
 
 $(".password").blur(
			function(){
				$(this).parent().removeClass("border_current")
				$(this).siblings().css("opacity","0.6")
				$(this).css("opacity","0.6")
			}
	)
 // 记住密码，自动登入复选框

	$(function () {
		$('#dl').on('click',function () {
			if($('input[name="dl"]').prop('checked')){
				//alert(dl);
				$('input[name="dl"]').prop('checked','checked');
				$('input[name="mima"]').prop('checked','checked');
			}else {
			}
		})
		
		$('#mima').on('click',function(){	
			if($('input[name="mima"]').prop('checked')) {
			}else {
				//alert(dl);
				$('input[name="dl"]').removeProp('checked','checked');
				$('input[name="mima"]').removeProp('checked','checked');				
			}
		});
	});

//错误提示和登入
$(".go").click(
	function(){
//		if($('.user').val() == "" || $('.password').val() == "" ) {
//			$(".tishi").html('账号密码不能为空！');
//			
//		}
//		else if($('.user').val() != "" && $('.password').val() != "" ) {		
//			$(".tishi").html('用户名或密码错误，请重新输入！');
//		}
	}
)
function login(){
    var username = $('.username').val();
    var password = $('.password').val();
    var remember = $("#mima").prop("checked");
    var autologin= $("#dl").prop("checked");
    var data = {};
    data["username"] = username;
    data["password"] = password;
    if($('.username').val() == "" || $('.password').val() == "" ) {
        $(".tishi").html('用户名和密码不能为空！');
    }
    else if($('.username').val() != "" && $('.password').val() != "" ) {
        $.post("index.php?s=/home/user/checklogin",data, function(result){
            if(result.status){
                if(remember){
                    setCookie("username",username);
                    setCookie("password",password);
                    setCookie("remember","remember");
                    setCookie("autologin","autologin");
                }else{
                    delCookie("username");
                    delCookie("password");
                    delCookie("remember");
                    delCookie("autologin");
                }
                location.href="index.php?s=/home/index/index";
            }else{
                $(".tishi").html(result.info);
            }
        }, 'json');
    }
}

//键盘事件  错误提示和登入
$(document).on('keydown',function(event) {
	if(event.keyCode == 13) {
	    login();
	}
});

//弹窗出现
$(".peizhi").click(
	function(){
		$("#tooltip_box").show()
	}
)

//点击登入

$('.go').click(function(){
    login();
});

//是否自动登录和记住密码
function auto(){
    //是否自动勾上记住密码.
    var isRember = getCookie("remember");
    if(isRember){
        $("#mima").prop("checked",true);
    }else{
        $("#mima").prop("checked",false);
    }
    //是否自动勾上自动登录
    var isAuto = getCookie("autologin");
    if(isAuto){
        $("#dl").prop("checked",true);
    }else{
        $("#dl").prop("checked",false);
    }

    //如果记住密码，则填充用户名和密码，反之清空
    var remember = $("#mima").prop("checked");
    if(remember){
        var username = getCookie("username");
        var password = getCookie("password");
        $(".username").val(username);
        $(".password").val(password);
    }else{
        $(".username").val("");
        $(".password").val("");
    }

    //如果自动登录，则触发点击登录按钮。
    var autologin = $("#dl").prop("checked");
    if(autologin){
        $(".go").click();
    }
}

//调用自动登录和记住密码函数。
$(function(){
   auto();
});




//本地是否存在sessionID,并返回
//	localStorage.setItem('login',infodata);
//	function get_session_id(){
//		var _session = localStorage["login"];
//		return _session;
//	}
//	
//	function is_login() {
//		var _session_login = get_session_id();
//		console.log(typeof(_session_login));
//		console.log(_session_login);
//		if(typeof(_session_login) == "undefined"){
//			return false;
//		}else {
//			return true;
//		}
//	};
