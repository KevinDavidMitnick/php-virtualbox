//修改密码退出
//$(".user_set ul").addClass("xiala_box")
//$(".sanjiao").addClass("sanjiao_yc")
$(".user_set_alert").click(
	function(){
		$(".user_set ul").toggle();
//		$(".user_set ul").toggleClass("xiala_box")
//		$(".sanjiao").toggleClass("sanjiao_yc")
	}
)
//弹窗
//修改密码
$("#tooltip_box_xm").hide()
$(".mm").click(
	function(){
		$("#tooltip_box_xm").show();
		$(".user_set ul").hide();
	}
)
//删除弹窗
$("#tooltip_box_s").hide()
$(".sc").click(
	function(){
		$("#tooltip_box_s").show()
	}
)
$(".plsc").click(
	function(){
		$("#tooltip_box_s").show()
	}
)
//创建用户弹窗
$("#tooltip_box_c").hide()
$(".cjyh").click(
	function(){
		$("#tooltip_box_c").show()
	}
)
//初始化弹窗
$("#tooltip_box_cs").hide()
$(".csh").click(
	function(){
		$("#tooltip_box_cs").show()
	}
)
$(".plcsh").click(
	function(){
		$("#tooltip_box_cs").show()
	}
)
//修改用户信息弹窗
$("#tooltip_box_x").hide()
$("#tooltip_box_px").hide()
$(".xiugai").click(
	function(){
		var chang_name = $(this).attr('truename');
		var chang_mum = $(this).attr('limit');
		var index = $(this).attr('index');
		var userName = $('.userName'+index).html();
		
		$("#tooltip_box_x").show();
		
		$(".yhm_mr").val(userName);
		$('.usertruename').val(chang_name);
		$('.userlimit').val(chang_mum);
	}
)
$(".plxg").click(
	function(){
		$("#tooltip_box_px").show()
	}
)
//关机弹窗
$(".close_1").click(
	function(){
		$("#tooltip_box_s").hide()
		$("#tooltip_box_c").hide()
		$("#tooltip_box_x").hide()
		$("#tooltip_box_cs").hide()
		$("#tooltip_box_px").hide()
		$("#tooltip_box_xm").hide()
	}
)
$(".tooltip_button input").click(
	function(){
		$("#tooltip_box_s").hide()
		$("#tooltip_box_x").hide()
		$("#tooltip_box_cs").hide()
		$("#tooltip_box_px").hide()
	}
)
$(".tooltip_button #qx").click(
	function(){
		$("#tooltip_box_c").hide()
	}
)
$(".tooltip_button #qx").click(
	function(){
		$("#tooltip_box_xm").hide()
	}
)
//单双数颜色
//var num=$("#simulator_c li").index()

$("#simulator_c li:even").css("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr=#99ffffff,endColorstr=#99ffffff);")
$("#simulator_c li:odd").css("filter","progid:DXImageTransform.Microsoft.gradient(startColorstr=#66ffffff,endColorstr=#66ffffff);")

//单数图标隐藏
//$("#c_4 span").children("img:even").css("display","none");
//$(".c_44 img").css("display","inline-block")

//开机，链接，删除，重启状态------开始
//
//var request_url = "s=/Home/Index/simulator.html";
//$.ajax({
//	type:"post",
//	url:"request_url",
//	async:true,
//	data:data,
//	dataType: "json",
//	success:function(data) {
//		message(data);
//	},
//	error:function () {
//		
//	}
//	
//});


$(function () {

			window.onload = function () {

            $("#simulator_c li").each(function(index){
                    var change=$("#simulator_c li").eq(index);
                    var str=change.find(".C_3-1").html();
//                    message(str)
                     if(str == '已关机') {
//                       message(str)
                         change.find('.close').css('display','block');
                         change.find('.open').css('display','none');
                     }
                     else {
                         change.find('.close').css('display','none');
                         change.find('.open').css('display','block');
                     }

              })

			}

				$('.close_status').on('click',function () {
					var index = $(this).attr('index');
						$('.C'+index).html('运行中');
						$('.close'+index).css('display','none');
						$('.open'+index).css('display','block');
				});

				$('.open_status').on('click',function () {
					var index = $(this).attr('index');
					$('.C'+index).html('已关机');
					$('.close'+index).css('display','block');
					$('.open'+index).css('display','none');
				})

});
//开机，链接，删除，重启状态------结束

//批量处理

// 复选框全选功能
// 选中个数
$(".all_yx").hide()


// 全选与全不选
$("#CheckedAll").click(
	function(){
		if (this.checked) {
			$("[name=items]:checkbox").prop("checked", true);
			$(".all_yx").show()
		}else{
			$("[name=items]:checkbox").prop("checked", false);
			$(".all_yx").hide()
		}
	}
)


// 有一个或多个不选时取消全选
//$("[name=items]:checkbox").click(
//	function(){
//		var flag=true;
//		$("[name=items]:checkbox").each(function(){
//			if(!this.checked){
//				flag=false;
//			}
//		})
//		$("#CheckedAll").prop("checked",flag);
//		$(".all_yx").hide()
//	})
//
//$("[name=items]:checkbox").click(
//	function(){
//		$("[name=items]:checkbox").each(function(){
//			if(!this.checked){
//				$(".all_yx").hide()
//			}else{
//				$(".all_yx").show()
//			}
//		})
//		})

$("[name=items]:checkbox").click(
	function(){
		var flag=true;
		$("[name=items]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
				$("#CheckedAll").prop("checked",flag);
				$(".all_yx").hide()
			}
		})
	})

$("[name=items]:checkbox").click(
	function(){
		$("[name=items]:checkbox").each(function(){
			if(!this.checked){
				$(".all_yx").hide()
			}
		})
		})
		
// 批量操作
// 
$(".pl").click(
			function(){
				$(".pl ul").toggleClass("pl_cx")
				}
			)

//$("#pl").blur(
//	function(){
//		$(".pl ul").delay(1000).removeClass("pl_cx")
//	}
//)
function plcz(){
	var flag01=false;
		$("[name=items]:checkbox").each(function(){
			if($(this).prop("checked") ){
				flag01 = true;
			}
		})
		if (flag01) {
			$(".pl_x").hide()	
		}else{
			$(".pl_x").show().css("display","inline-block")
			$(".pl ul").removeClass("pl_cx")
				}
			
		}
	

$("[name=items]:checkbox").click(
	plcz)

$("#CheckedAll").click(
	plcz)

// 双击修改真实姓名
//function ShowElement(element) {
//      var oldhtml = element.innerText;
////      console.log('第一行',oldhtml);
//      //创建新的input元素
//      var newobj = document.createElement('input');
////      console.log('新，第二行',newobj);
//      //为新增元素添加类型
//      newobj.type = 'text';
////      console.log('新，第三行',newobj.type);
//      //为新增元素添加value值
//      newobj.value = oldhtml;
////      console.log('新，第四行',newobj.value);
//      //设置该标签的子节点为空
//      element.innerText = '';
////      console.log('新，第五行',element.innerHTML);
//      //添加该标签的子节点，input对象
//      element.appendChild(newobj);
////      console.log(element,'新，第六行',element.innerHTML);
//      //设置获得光标，触发
//      newobj.focus();
//      //为新增元素添加光标离开事件,失去焦点
//      newobj.onblur = function() {
////          element.innerHTML = this.value == this.value ? this.value : oldhtml;
//          element.innerHTML = this.value == "" ? oldhtml : this.value;
////          element.innerHTML = this.value.replace(/\s+/g,'')=='';
//          //当触发时判断新增元素值是否为空，为空则不修改，并返回原有值 
//      }
//      //设置选择文本的内容或设置光标位置（两个参数：start,end；start为开始位置，end为结束位置；如果开始位置和结束位置相同则就是光标位置）
////      newobj.createTextRange(oldhtml.length, oldhtml.length);
//  }

//刷新
//$(function(){
//	$("#sx").click(
//	function(){
//		message(0)
//		$("#simulator_c").load(location.href + "#simulator_c");
//	}
//)
//})
$(function(){
	$("#sx").click(
	function(){
		$("#simulator_c").load(location.reload());
	}
)
})


//弹窗筛查

$("#xj_sm").click(
	function(){
       create();
	}
)

//		$('.yhm').on('propertychange',function () {
//			message(0);
//			if(('.yhm').val('')){
//				message(1);
//				$('.yhm_span').html('不能为空');
//			}
//		});

//修改密码

$(".mm").click(
	function(){
		$("#tooltip_box_xm").find(".ymm,.xmm,.xmmqr").attr("value","")
		$(".ymm_div").hide();
		$(".xmm_div").hide();
		$(".xmmqr_div").hide();
	}
)
$("#tooltip_box_xm #qd").click(
	function(){
			if($(".ymm").val()==''){
   			$(".ymm_div").html('原密码不能为空').addClass("ts_h").show()
   			return false
   		}else{
   			$(".ymm_div").hide()
   		}
			if($(".xmm").val().length<6){
   			$(".xmm_div").html('密码至少为六位数').addClass("ts_h").show()
   			return false
   		}
			else{
   			$(".xmm_div").hide()
   		}
   			if($(".xmmqr").val()!=$(".xmm").val()){
   			$(".xmmqr_div").html('两次密码输入不一致').addClass("ts_h").show()
   			return false
        }else{
            $(".ymm_div").hide()
            $(".xmm_div").hide()
            $(".xmmqr_div").hide()
            $("#tooltip_box_xm").hide()
            modify_passwd();
        }
	}

)

//弹窗内input只能输入正整数
function keyPress() {    
         var keyCode = event.keyCode;    
         if ((keyCode >= 48 && keyCode <= 57))    
        {    
             event.returnValue = true;    
         } else {    
               event.returnValue = false;    
        }    
     }    

//隐藏消息提示.
$("#hint").hide()

//add by liucong.
function mark_delete(vmname){
    delete_vmname = [] ;
    delete_vmname.push(vmname);
}

function  modify_passwd(){
	var old = $(".ymm").val();
	var password = $(".xmm").val();
    $.post("index.php?s=/home/user/profile",{"old":old,"password":password}, function(result){
    	message(result)
    }, 'json');
}

$("#ym_qd").click(function(){
    var page = parseInt($(".ym_ys").val());
    if(page >= (PAGE_NUM )) {
        page = PAGE_NUM -1 ;
    }else if(page <= 0){
        page = 0 ;
    }else{
        page = page -1 ;
    }
    location.href="index.php?s=/home/index/simulator&p="+page;
});

//键盘翻页
//$(document).on('keydown',function(event){
//	if(event.keyCode == 13) {
//		var page = parseInt($(".ym_ys").val());
//	    if(page >= (PAGE_NUM )) {
//	        page = PAGE_NUM -1 ;
//	    }else if(page <= 0){
//	        page = 0 ;
//	    }else{
//	        page = page -1 ;
//	    }
//	    location.href="index.php?s=/home/index/simulator&p="+page;
//	}
//})




//创建虚拟机
function create(){
    $.post("index.php?s=/home/index/vm_create",{}, function(result){
        var func = "location.href='index.php?s=/home/index/simulator'";
        message(result,func);
    }, 'json');
}

//开机
function start(vmname){
    var data ={"vmname":vmname};
    $.post("index.php?s=/home/index/vm_start",data, function(result){
        message(result);
    }, 'json');
}

//关机
function shutdown(vmname){
    var data ={"vmname":vmname};
    $.post("index.php?s=/home/index/vm_stop",data, function(result){
       message(result);
    }, 'json');
}

//删除
function destroy()
{
    var len = delete_vmname.length ;
    var failure = 0 ;
    var ret = {};

    if(1 == len){
        var data ={"vmname":delete_vmname[0]};
        $.post("index.php?s=/home/index/vm_delete",data, function(result){
            var func = "location.href='index.php?s=/home/index/simulator'";
           message(result,func);
        }, 'json');
        delete_vmname = [];
    }else{
        for( i in delete_vmname){
            var data ={"vmname":delete_vmname[i]};
            $.post("index.php?s=/home/index/vm_delete",data, function(result){
            }, 'json');
        }
        delete_vmname = [];
        ret['status'] = 1 ;
        ret['info']   = len+"个模拟器删除成功，"+failure+"个模拟器删除失败。";
        var func = "location.href='index.php?s=/home/index/simulator'";
        message(ret,func);
    }
}

//重启
function reboot(vmname)
{
    var data ={"vmname":vmname};
    $.post("index.php?s=/home/index/vm_reboot",data, function(result){
        message(result);
    }, 'json');
}

//批量操作
function batch_operation(operation){
    var vms = [];
    $("input[ name = 'items' ]:checked").each(function () {
        vms.push($(this).attr("vmname"));
    });
    //判断是否选中了全选.
    if($("#CheckedAll").prop("checked")){
        vms = vmarr;
    }
    switch(operation){
        case "start":
            batch_start(vms);
            break;
        case "shutdown":
            batch_shutdown(vms);
            break;
        case "reboot":
            batch_reboot(vms);
            break;
        case "destroy":
            delete_vmname = vms;
            break;
        case "connect":
            batch_connect(vms);
            break;
        default:
            break;
    }
}

function batch_start(vms){
    var success = vms.length ;
    var failure = 0 ;
    var ret = {};
    for( i in vms){
        var data ={"vmname":vms[i]};
        $.post("index.php?s=/home/index/vm_start",data, function(result){
        }, 'json');
    }
    ret['status'] = 1 ;
    ret['info']   = success+"个模拟器启动成功，"+failure+"个模拟器启动失败。";
    var func = "location.href='index.php?s=/home/index/simulator'";
    message(ret,func);
}

function batch_shutdown(vms){
    var success = vms.length ;
    var failure = 0 ;
    var ret = {};
    for( i in vms){
        var data ={"vmname":vms[i]};
        $.post("index.php?s=/home/index/vm_stop",data, function(result){
        }, 'json');
    }
    ret['status'] = 1 ;
    ret['info']   = success+"个模拟器关闭成功，"+failure+"个模拟器关闭失败。";
    var func = "location.href='index.php?s=/home/index/simulator'";
    message(ret,func);
}

function batch_reboot(vms){
    var success = vms.length ;
    var failure = 0 ;
    var ret = {};
    for( i in vms){
        var data ={"vmname":vms[i]};
        var status = $("#"+vms[i]).find("#c_3").html();
        if(status == "已关机") {
            $.post("index.php?s=/home/index/vm_start", data, function (result) {
            }, 'json');
        }else{
            $.post("index.php?s=/home/index/vm_reboot", data, function (result) {
            }, 'json');
        }
    }
    ret['status'] = 1 ;
    ret['info']   = success+"个模拟器重启成功，"+failure+"个模拟器重启失败。";
    var func = "location.href='index.php?s=/home/index/simulator'";
    message(ret,func);
}

function batch_connect(vms){
    for( i in vms){
    }

}

