<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: 麦当苗儿 <zuojiazi@vip.qq.com> <http://www.zjzit.cn>
// +----------------------------------------------------------------------

namespace Home\Controller;
use OT\DataDictionary;

/**
 * 前台首页控制器
 * 主要获取首页聚合数据
 */
class IndexController extends HomeController {

	//系统首页
    public function index(){
        $uid  = is_login();
        $uid || $this->redirect('User/login');

        if($uid == 1){
            $search = trim($_REQUEST['search']);
            if($search){
                $where['username'] = array("like", "%".$search."%");
                $where['truename'] = array("like", "%".$search."%");
                $where['_logic'] = 'OR';
                $map['_complex'] = $where;
            }
            $p = intval(trim($_REQUEST["p"]));
            $map["id"] = array("neq",$uid);
            $total = D('ucenter_member')->where($map)->count();
            $pagenum = ($total % VM_LIMIT) == 0  ? ($total /VM_LIMIT) : floor(($total / VM_LIMIT ))+ 1;
            $prev = $p <= 0 ? 0 : $p - 1 ;
            $next = $p >= ($pagenum -1)  ? $pagenum -1 : $p + 1;
            $cur  = ($p == ($pagenum - 1)) ? $next + 1 : $next;
            $list = D('ucenter_member')->where($map)->order("username")->limit($p*VM_LIMIT.",".VM_LIMIT)->select();
            $users = D('ucenter_member')->where($map)->getField("id",true);
            $userlist = "";
            foreach ($users as $item){
                $userlist = $userlist ? $item.",".$userlist : $item;
            }
            $this->assign("p",$p);
            $this->assign("prev",$prev);
            $this->assign("cur",$cur);
            $this->assign("next",$next);
            $this->assign("total",$total);
            $this->assign("pagenum",$pagenum);
            $this->assign("user_jump",VM_LIMIT * $p);
            $this->assign('list',$list);
            $this->assign('userlist',$userlist);
            $this->assign("search",$search);
            $this->display();
        }else{
            $this->redirect('Index/simulator');
        }
    }

    //模拟器管理页面.
    public function simulator(){
        $uid  = is_login();
        $p = intval(trim($_REQUEST["p"]));
        $total = D('vminfo')->where(array("uid" => $uid))->count();
        $pagenum = ($total % VM_LIMIT) == 0  ? ($total /VM_LIMIT) : floor(($total / VM_LIMIT ))+ 1;
        $prev = $p  ? $p - 1 : 0 ;
        $next = $p >= ($pagenum -1)  ? $pagenum -1 : $p + 1;
        $cur  = ($p == ($pagenum - 1)) ? $next + 1 : $next;
        $username = D('Member')->where(array("uid" => $uid))->getField("nickname");
        $list = D('Member')->get_vminfo($uid,$p);
        $vmnames = D('vminfo')->where(array("uid" => $uid))->getField("vmname",true);
        $vmlist = "";
        foreach ($vmnames as $item){
            $vmlist = $vmlist ? $item.",".$vmlist : $item;
        }
        $this->assign("p",$p);
        $this->assign("prev",$prev);
        $this->assign("cur",$cur);
        $this->assign("next",$next);
        $this->assign("total",$total);
        $this->assign("pagenum",$pagenum);
        $this->assign("username",$username);
        $this->assign("vm_jump",VM_LIMIT * $p);
        $this->assign('list',$list);
        $this->assign('vmlist',$vmlist);
//        dump($pagenum);
//        dump($p);
//        dump($prev);
//        dump($next);
        $this->display();
    }

    public function vm_create(){
        $vm['uid'] = is_login();//trim($_REQUEST['uid']);
        //判断是否超过最大模拟器开通限制，如果超过则失败返回.
        $cnt = M("vminfo")->where(array("uid" => $vm["uid"]))->count();
        //获取用户的模拟器限制数
        $limit = D("ucenter_member")->where(array("id" => $vm["uid"]))->getField("update_time");
        if($cnt >= $limit){
            $fail["info"]="限制创建".$limit."个模拟器!";
            $fail['status']=0;
            $this->ajaxReturn($fail);
            return;
        }

        $vm['vmname'] = M('vminfo')->order('vmname DESC')->getField('vmname')+1;
        $vm['ip'] = VMIP;
        $vm['port'] = M('vminfo')->order('port DESC')->getField('port')+1;
        $vm['port'] = $vm['port'] < 1024 ? 6001 : $vm['port'];
        $vm['vmid'] = "已关机";

        //create vm on local system.
        $message = array(
            'func' => "VmCreate",
            'vm' => array("vmname" => $vm['vmname'])
        );
        sendMessage($message);
        $success["info"]="模拟器创建成功";
        $success["status"]=1;

        $fail["info"]="模拟器创建失败";
        $fail['status']=0;
        $id = D('vminfo')->add($vm);
        if($id){
            $this->ajaxReturn($success);
        }else{
                $this->ajaxReturn($fail);
        }
    }

    public function vm_start(){
        $vmname = trim($_POST["vmname"]);
        $vmport = M('vminfo')->where(array("vmname" => $vmname))->getField('port');
        $vm['vmid'] = "运行中";

        //create vm on local system.
        $message = array(
            'func' => "VmStart",
            'vm' => array("vmname" => $vmname,"vmport" => $vmport)
        );
        $str = sendMessage($message);
        $success["info"]="模拟器启动成功";
        $success["status"]=1;
        $success["str"] = $str;

        $fail["info"]="模拟器启动失败";
        $fail['status']=0;
        $id = D('vminfo')->where("vmname=".$vmname)->save($vm);
        if($id){
            $this->ajaxReturn($success);
        }else{
            $this->ajaxReturn($fail);
        }
    }

    public function vm_stop(){
        $vmname = trim($_POST["vmname"]);
        $vm['vmid'] = "已关机";

        //create vm on local system.
        $message = array(
            'func' => "VmStop",
            'vm' => array("vmname" => $vmname)
        );
        sendMessage($message);
        $success["info"]="模拟器关闭成功";
        $success["status"]=1;

        $fail["info"]="模拟器关闭失败";
        $fail['status']=0;
        $id = D('vminfo')->where("vmname=".$vmname)->save($vm);
        if($id){
            $this->ajaxReturn($success);
        }else{
            $this->ajaxReturn($fail);
        }
    }

    public function vm_reboot(){
        $vmname = trim($_POST["vmname"]);
        $vmport = M('vminfo')->where(array("vmname" => $vmname))->getField('port');

        //create vm on local system.
        $message = array(
            'func' => "VmReboot",
            'vm' => array("vmname" => $vmname,"vmport" => $vmport)
        );
        sendMessage($message);
        $success["info"]="模拟器重启成功";
        $success["status"]=1;

        $this->ajaxReturn($success);
    }

    public function vm_delete(){
        $vmname = trim($_POST["vmname"]);

        //create vm on local system.
        $message = array(
            'func' => "VmDelete",
            'vm' => array("vmname" => $vmname)
        );
        sendMessage($message);
        $success["info"]="模拟器删除成功";
        $success["status"]=1;

        $fail["info"]="模拟器删除失败";
        $fail['status']=0;
        $id = D('vminfo')->where("vmname=".$vmname)->delete();
        if($id){
            $this->ajaxReturn($success);
        }else{
            $this->ajaxReturn($fail);
        }
    }

    public function manage(){
        $map['id']  =   array('neq',1);
        $User = D('ucenter_member'); // 实例化User对象
	$count = $User->where($map)->count();// 查询满足要求的总记录数
	$Page = new \Think\Page($count,8);// 实例化分页类 传入总记录数和每页显示的记录数(25)

        $Page->lastSuffix = false;
	$Page -> setConfig('header','(总用户数：%TOTAL_ROW%个)');
	$Page -> setConfig('first','首页');
	$Page -> setConfig('last','尾页');
	$Page -> setConfig('prev','上一页');
	$Page -> setConfig('next','下一页');
	$Page -> setConfig('theme','%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');

	// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
	$list = $User->where($map)->order('username')->limit($Page->firstRow.','.$Page->listRows)->select();
	$show = $Page->show();// 分页显示输出
	$this->assign('list',$list);// 赋值数据集
	$this->assign('page',$show);// 赋值分页输出
	$this->display(); // 输出模板    
    }
}






